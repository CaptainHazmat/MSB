﻿ITEM.name = "Crye Precision - AVS"
ITEM.desc = "Разгрузочная система AVS, оснащенная легкими бронеплитами из комбинированных материалов. Один из самых удобных для ношения плитников. Производство Crye Precision. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 80610
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.addition = 3
ITEM.weight = 8.70

ITEM.model = "models/tushingame/tg_armor/tg_avs.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}