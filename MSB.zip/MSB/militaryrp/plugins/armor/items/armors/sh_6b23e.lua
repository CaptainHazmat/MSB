﻿ITEM.name = "6Б23 (Цифра)"
ITEM.desc = "Общевойсковой бронежилет Забрало-8 является средством индивидуальной бронезащиты личного состава боевых подразделений сухопутных войск, ВДВ, морской пехоты и т.д. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-3 класс защиты"
ITEM.price = 51443
ITEM.ric = 25
ITEM.dmgsteal = 35
ITEM.exRender = false
ITEM.weight = 7.90

ITEM.model = "models/tushingame/tg_armor/tg_6b13_emr.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-0.89999997615814, -0.40000000596046, 200),
	ang = Angle(90, 0, 180),
	fov = 8.3
}

local DuseArmor = {
	"armbr",
	"trapk",
	"dlarmor"
}