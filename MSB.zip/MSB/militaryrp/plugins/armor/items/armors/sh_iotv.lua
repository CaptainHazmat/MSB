﻿ITEM.name = "IOTV"
ITEM.desc = "Gen IV предназначен для обеспечения максимальной свободы передвижения, требуемой для правильного положения стрельбы с гибкостью для выполнения и маневрирования. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-6 класс защиты"
ITEM.price = 340000
ITEM.ric = 30
ITEM.dmgsteal = 70
ITEM.exRender = false
ITEM.weight = 20

ITEM.model = "models/tushingame/tg_armor/tg_iotv.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-1, 0, 200),
	ang = Angle(90, 0, 180),
	fov = 11
}

