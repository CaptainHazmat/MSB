﻿ITEM.name = "LBT - Slick (Олива)"
ITEM.desc = "Чехол под бронеплиты фирмы London Bridge Trading. Максимально простой дизайн, предназначенный для совместного использования с нагрудными разгрузочными системами. Версия в оливковом цвете. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-6 класс защиты"
ITEM.price = 170000
ITEM.ric = 30
ITEM.dmgsteal = 60
ITEM.exRender = false
ITEM.weight = 9.70

ITEM.model = "models/tushingame/tg_armor/tg_slick_green.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-1, 0, 200),
	ang = Angle(90, 0, 180),
	fov = 11
}


