ENT.Type 		= "anim"
ENT.PrintName	= "Doors Base"
ENT.Author		= "WickRabbit" 
 
ENT.Spawnable		= false --Spawnable?
ENT.AdminSpawnable	= false --If spawnable, is it admin only?
ENT.AutomaticFrameAdvance = true   
 