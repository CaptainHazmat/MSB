﻿ITEM.name = "Жук-3"
ITEM.desc = "Бронежилет для журналистов, работающих в зонах военных действий. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-3 класс защиты"
ITEM.price = 45000
ITEM.ric = 15
ITEM.dmgsteal = 20
ITEM.exRender = false
ITEM.weight = 5.20

ITEM.model = "models/tushingame/tg_armor/tg_vestpress.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-0.89999997615814, -0.40000000596046, 200),
	ang = Angle(90, 0, 180),
	fov = 8.3
}

