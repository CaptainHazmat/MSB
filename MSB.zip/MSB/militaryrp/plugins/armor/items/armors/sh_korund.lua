﻿ITEM.name = "Корунд-ВМ"
ITEM.desc = "Бронежилет длительного ношения Корунд-ВМ, принятый на вооружение в ряды сотрудников МВД России. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-5 класс защиты"
ITEM.price = 112746
ITEM.ric = 35
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.weight = 9.80

ITEM.model = "models/tushingame/tg_armor/tg_korund.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-0.89999997615814, -0.40000000596046, 200),
	ang = Angle(90, 0, 180),
	fov = 8.3
}