﻿ITEM.name = "Кассета Раскумара"
ITEM.desc = "Список треков:\n1. Firelake - Against the ionized odds\n2. Firelake - Dirge For The Planet\n3. Firelake - Life to Forget"
ITEM.price = 51490
ITEM.model = "models/tushingame/tg_props/tg_cassette_white.mdl"

ITEM.cassette_options = {}
ITEM.cassette_options['radio/firelake_1.ogg'] = {dur = 198}
ITEM.cassette_options['radio/firelake_2.ogg'] = {dur = 263}
ITEM.cassette_options['radio/firelake_3.ogg'] = {dur = 289}






