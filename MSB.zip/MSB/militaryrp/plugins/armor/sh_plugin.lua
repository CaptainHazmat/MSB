PLUGIN.name = "armor"
PLUGIN.author = "Dash"
PLUGIN.desc = "Add armor to ns 1.1."

nut.util.include("sv_plugin.lua")

