﻿ITEM.name = "6Б13 (Цифра)"
ITEM.desc = "Общевойсковой штурмовой бронежилет является средством индивидуальной бронезащиты личного состава боевых подразделений сухопутных войск, ВДВ, морской пехоты и т.д. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 45000
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.weight = 10.50

ITEM.model = "models/tushingame/tg_armor/tg_6b23_emr.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}

local DuseArmor = {
	"kevlar",
	"armbr",
	"trapk",
	"kevlar",
	"dlarmor"
}