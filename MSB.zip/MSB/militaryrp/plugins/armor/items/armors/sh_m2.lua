﻿ITEM.name = "ANA Tactical M2"
ITEM.desc = "Разгрузочный жилет M2, созданный с использованием передового опыта сотрудников спецподразделений. Производство ANA Tactical. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 57665
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.addition = 3
ITEM.weight = 7

ITEM.model = "models/tushingame/tg_armor/tg_m2.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-0.89999997615814, -0.40000000596046, 200),
	ang = Angle(90, 0, 180),
	fov = 8.3
}