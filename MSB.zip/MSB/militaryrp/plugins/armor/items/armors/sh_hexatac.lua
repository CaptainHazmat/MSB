﻿ITEM.name = "Hexatac"
ITEM.desc = "Чехол под бронеплиты фирмы Hexatac. Минималистичный вариант, предназначенный для совместного использования с нагрудными разгрузочными системами. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-5 класс защиты"
ITEM.price = 102001
ITEM.ric = 35
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.weight = 8.50

ITEM.model = "models/tushingame/tg_armor/tg_hexatac.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-0.89999997615814, -0.40000000596046, 200),
	ang = Angle(90, 0, 180),
	fov = 8.3
}

