﻿ITEM.name = "NFM THOR"
ITEM.desc = "Бронежилет THOR Concealed Reinforced Vest позволяет скрытно или открыто использовать мягкие баллистические панели. Производство NFM. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 56610
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.weight = 9

ITEM.model = "models/tushingame/tg_armor/tg_thor.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}

