local V = {
			Name = "Uaz", 
			Class = "prop_vehicle_jeep",
			Category = "BIOTOPE Vehicle",
			Author = "Dash",
			Information = "Driveable Uaz by _TailS_",
			Model = "models/TailS Models/DayZ/Uaz/uaz.mdl",
			KeyValues = {
vehiclescript	=	"scripts/vehicles/uaz/uaz.txt"
						}
			}
list.Set("Vehicles", "dayz_uaz", V)