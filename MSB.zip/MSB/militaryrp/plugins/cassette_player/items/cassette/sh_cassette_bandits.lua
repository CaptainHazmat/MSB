﻿ITEM.name = "Кассета Братвы"
ITEM.desc = "Отлично подойдет для любителей тюремной романтики.\n\nСписок треков:\n1. Михаил Круг - Владимирский Централ\n2. Михаил Круг - Водочку пьём\n3. Тема бандитов\n4. Бутырка - Не трогай осень\n5. Воровайки - Хоп, мусорок\n6. Бутырка - Вернусь домой"
ITEM.price = 57940
ITEM.model = "models/tushingame/tg_props/tg_cassette_ad60.mdl"

ITEM.cassette_options = {}
ITEM.cassette_options['radio/bandit_r_1.ogg'] = {dur = 266}
ITEM.cassette_options['radio/bandit_r_2.ogg'] = {dur = 180}
ITEM.cassette_options['radio/bandit_r_3.ogg'] = {dur = 111}
ITEM.cassette_options['radio/bandit_r_4.ogg'] = {dur = 319}
ITEM.cassette_options['radio/bandit_r_5.ogg'] = {dur = 187}
ITEM.cassette_options['radio/bandit_r_6.ogg'] = {dur = 251}
ITEM.cassette_options['radio/bandit_r_7.ogg'] = {dur = 205}


