﻿ITEM.name = "5.11 Tactical - TacTec"
ITEM.desc = "Разгрузочный жилет с набором подсумков для работы со штурмовыми винтовками. Производство 5.11 Tactical. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 49555
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.addition = 5
ITEM.weight = 9.50

ITEM.model = "models/tushingame/tg_armor/tg_tactec.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}