﻿ITEM.name = "Портативный плеер"
ITEM.desc = "Для тех, кто «шарит». \n\nХАРАКТЕРИСТИКИ: \n-технологическое приспособление\n-не требует подзарядки\n-повсеместное применение\n\nДля активации необходимо использовать кассету в инвентаре."
ITEM.price = 35678
ITEM.model = "models/tushingame/tg_props/tg_portable_player.mdl"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	pos = Vector(73, 2.9500000476837, 200),
	ang = Angle(110.06369781494, 2.2929935455322, 4.5859870910645),
	fov = 2.17
}
ITEM.exRender = false
ITEM.weight = 1.12