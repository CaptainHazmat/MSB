﻿ITEM.name = "Ars Arma - CPC MOD.1"
ITEM.desc = "Первое поколение модификации бронежилета СРС дизайна Crye Precision, адаптированной для сотрудников силовых структур РФ. Производство Ars Arma. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 48933
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.addition = 4
ITEM.weight = 8.50

ITEM.model = "models/tushingame/tg_armor/tg_arscpc.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}

