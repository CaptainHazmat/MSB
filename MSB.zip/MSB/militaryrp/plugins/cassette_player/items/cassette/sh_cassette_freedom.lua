﻿ITEM.name = "Кассета Свободы"
ITEM.desc = "Список треков:\n1. Джайа - Малиновые пальмы\n2. Тема свободы"
ITEM.price = 44240
ITEM.model = "models/tushingame/tg_props/tg_cassette_red1.mdl"

ITEM.cassette_options = {}
ITEM.cassette_options['radio/freedm_r_1.ogg'] = {dur = 290}
ITEM.cassette_options['radio/freedm_r_2.ogg'] = {dur = 111}


