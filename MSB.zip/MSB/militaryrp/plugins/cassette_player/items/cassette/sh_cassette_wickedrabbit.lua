﻿ITEM.name = "Кассета с роком"
ITEM.desc = "Список треков:\n1. Сектор Газа - Лирика\n2. Сплин – Линия Жизни\n3. Сектор газа - Бомж\n4. Виктор Цой - Перемен\n5. Кино – Группа крови\n6. Кино – Звезда по имени Солнце\n7. Сектор Газа - Туман"
ITEM.price = 236940
ITEM.model = "models/tushingame/tg_props/tg_cassette_wicked.mdl"

ITEM.cassette_options = {}
ITEM.cassette_options['radio/rabbit_r_1.ogg'] = {dur = 260}
ITEM.cassette_options['radio/rabbit_r_2.ogg'] = {dur = 182} 
ITEM.cassette_options['radio/rabbit_r_3.ogg'] = {dur = 198} 
ITEM.cassette_options['radio/rabbit_r_4.ogg'] = {dur = 295}
ITEM.cassette_options['radio/rabbit_r_5.ogg'] = {dur = 282}
ITEM.cassette_options['radio/rabbit_r_6.ogg'] = {dur = 225}
ITEM.cassette_options['radio/rabbit_r_7.ogg'] = {dur = 223}
