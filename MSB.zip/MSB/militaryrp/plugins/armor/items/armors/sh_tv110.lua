﻿ITEM.name = "TV-110"
ITEM.desc = "Разгрузочный жилет с бронепластинами WARTECH - TV-110 \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 63000
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.addition = 10
ITEM.weight = 10.30

ITEM.model = "models/tushingame/tg_armor/tg_tv110.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}

