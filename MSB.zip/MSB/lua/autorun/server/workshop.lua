---Materials
resource.AddWorkshop ( "3155274996" ) --MS Materials

---Pack
resource.AddWorkshop ( "207739713" ) --Nutscript Content
resource.AddWorkshop ( "1344143281" ) --Русский ulx+ulib
resource.AddWorkshop ( "220336312" ) --PermaProps
resource.AddWorkshop ( "3063511642" ) --ConVar
resource.AddWorkshop ( "3242733646" ) --MagicStar Sounds

---Models
resource.AddWorkshop ( "3235922784" ) --MagicStar Models

---Weapon
resource.AddWorkshop ( "3235527622" ) --MagicStar Weapons

---Props
resource.AddWorkshop ( "3235953375" ) --MagicStar Items

---Vehicles
resource.AddWorkshop ( "3245458493" ) --MagicStar Vehicles