﻿ITEM.name = "Ars Arma - A18 Сканда"
ITEM.desc = "Разгрузочный жилет под бронепластины со множеством различных подсумков. Производство Ars Arma. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 56000
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.addition = 3
ITEM.weight = 8.20

ITEM.model = "models/tushingame/tg_armor/tg_arsarma.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}