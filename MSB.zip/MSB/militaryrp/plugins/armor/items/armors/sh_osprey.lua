﻿ITEM.name = "CQC Osprey"
ITEM.desc = "Разгрузочная система-бронежилет Osprey, активно использующийся британской армией и специалистами. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-6 класс защиты"
ITEM.price = 250000
ITEM.ric = 30
ITEM.dmgsteal = 60
ITEM.exRender = false
ITEM.addition = 5
ITEM.weight = 12.50

ITEM.model = "models/tushingame/tg_armor/tg_osprey.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-0.89999997615814, -0.40000000596046, 200),
	ang = Angle(90, 0, 180),
	fov = 8.3
}