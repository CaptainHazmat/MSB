﻿ITEM.name = "Crye Precision - CPC"
ITEM.desc = "CAGE PLATE CARRIER (CPC) предлагает непревзойденный комфорт и поддержку груза в низкопрофильной конфигурации плейткерриера. Производство Crye Precision. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-5 класс защиты"
ITEM.price = 140570
ITEM.ric = 35
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.addition = 4
ITEM.weight = 9.60

ITEM.model = "models/tushingame/tg_armor/tg_arsknight.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}

