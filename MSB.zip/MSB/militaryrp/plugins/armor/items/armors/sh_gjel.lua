﻿ITEM.name = "Гжель-К"
ITEM.desc = "Штурмовой бронежилет «Гжель» предназначен для штурмовых подразделений МВД и других силовых ведомств. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-5 класс защиты"
ITEM.price = 87333
ITEM.ric = 25
ITEM.dmgsteal = 55
ITEM.exRender = false
ITEM.weight = 8.90

ITEM.model = "models/tushingame/tg_armor/tg_gjel.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-0.89999997615814, -0.40000000596046, 200),
	ang = Angle(90, 0, 180),
	fov = 8.3
}

