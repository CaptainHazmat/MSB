﻿ITEM.name = "6Б2"
ITEM.desc = "Старый армейский бронежилет времен войны в Афганистане, в основном предназначенный для защиты от пистолетных пуль и осколков. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-2 класс защиты"
ITEM.price = 27079
ITEM.ric = 5
ITEM.dmgsteal = 10
ITEM.exRender = false
ITEM.weight = 5.40

ITEM.model = "models/tushingame/tg_armor/tg_6b2.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(-0.89999997615814, -0.40000000596046, 200),
	ang = Angle(90, 0, 180),
	fov = 8.3
}

local DuseArmor = {
	"armbr",
	"trapk",
	"dlarmor"
}