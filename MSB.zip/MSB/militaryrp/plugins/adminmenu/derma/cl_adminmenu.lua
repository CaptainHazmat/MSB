local PANEL = {}
local curplayer = LocalPlayer()
local PLUGIN = PLUGIN
local CharData = {}
local ScrW, ScrH = ScrW()*0.6, ScrH()*0.8

	function PANEL:Init()
		if IsValid(nut.gui.admingui) then
			nut.gui.admingui:Remove()
		end
		nut.gui.admingui = self
		
		self:SetSize(ScrW, ScrH)
		self:Center()
		self:MakePopup()
		self:SetTitle("Админ меню")
		
		self.scroll = self:Add("DScrollPanel")
		self.scroll:Dock(FILL)
		self.scroll:DockMargin(5, 5, ScrW*0.75, 5)
		self.scroll.VBar:SetWide(5)
		self.scroll.Paint = function(this, w, h)
			-- surface.SetMaterial("vgui/rampka.png")
			-- surface.DrawTexturedRect(2, 2, w - 4, h - 4)
			surface.SetDrawColor(0, 0, 0, 150)
			surface.DrawRect(0, 0, w, h)
		end
		
		local sbar0 = self.scroll:GetVBar()
		function sbar0:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))
		end
		function sbar0.btnUp:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(200, 100, 0))
		end
		function sbar0.btnDown:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(200, 100, 0))
		end
		function sbar0.btnGrip:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(65, 65, 65))
		end
		
		self.player = self:Add("DPanel")
		self.player:Dock(FILL)
		self.player:DockMargin(ScrW*0.25, 5, 5, 5)
		self.player.Paint = function(s, w, h) 
			surface.SetDrawColor(0, 0, 0, 150)
			surface.DrawRect(0, 0, w, h)
		end
		
		self.player.model = self.player:Add("nutModelPanel")
		self.player.model:SetFOV(50)
		self.player.model.enableHook = false
		self.player.model.copyLocalSequence = false
		self.player.model:SetSize(128, 128)
		self.player.model:SetModel(LocalPlayer():GetModel())
		
		self.player.name = self.player:Add("DLabel")
		self.player.name:SetColor(color_white)
		self.player.name:SetFont("nutSmallFont")
		self.player.name:SetText("Имя : " .. LocalPlayer():Name())
		self.player.name:Dock(TOP)
		self.player.name:DockMargin(128, 0, 0, 5)
		
		self.player.steam = self.player:Add("DLabel")
		self.player.steam:SetColor(color_white)
		self.player.steam:SetFont("nutSmallFont")
		self.player.steam:SetText("SteamID : " ..LocalPlayer():SteamID() )
		self.player.steam:Dock(TOP)
		self.player.steam:DockMargin(128, 0, 0, 5)
		
		self.player.faction = self.player:Add("DLabel")
		self.player.faction:SetColor(color_white)
		self.player.faction:SetFont("nutSmallFont")
		self.player.faction:SetText("Фракция : " ..team.GetName(LocalPlayer():Team()) )
		self.player.faction:Dock(TOP)
		self.player.faction:DockMargin(128, 0, 0, 5)
		
		self.player.money = self.player:Add("DLabel")
		self.player.money:SetColor(color_white)
		self.player.money:SetFont("nutSmallFont")
		self.player.money:SetText("Деньги : " ..LocalPlayer():getChar():getMoney() )
		self.player.money:Dock(TOP)
		self.player.money:DockMargin(128, 0, 0, 5)
		
		self.player.scrollname1 = self.player:Add("DLabel")
		self.player.scrollname1:SetColor(color_white)
		self.player.scrollname1:SetFont("nutSmallFont")
		self.player.scrollname1:SetText("___________Данные __________________________________ Команды_________")
		self.player.scrollname1:Dock(TOP)
		self.player.scrollname1:DockMargin(5, 20, 5, 5)
		
		local datalist = {}
		local datalist2 = {}
		self.player.data = self.player:Add("DScrollPanel")
		self.player.data:Dock(FILL)
		self.player.data:DockMargin(5, 5, ScrW*0.50, 5)
		self.player.data.VBar:SetWide(5)
		self.player.data.Paint = function(s, w, h) 
			surface.SetDrawColor(0, 0, 0, 150)
			surface.DrawRect(0, 0, w, h)
		end
		local sbar3 = self.player.data:GetVBar()
		function sbar3:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))
		end
		function sbar3.btnUp:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(200, 100, 0))
		end
		function sbar3.btnDown:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(200, 100, 0))
		end
		function sbar3.btnGrip:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(65, 65, 65))
		end
		
		for k,v in pairs(LocalPlayer():getChar():getData()) do
			local key = self.player.data:Add("DLabel")
			key:SetColor(color_white)
			key:SetFont("nutSmallFont")
			key:Dock(TOP)
			key:DockMargin(5, 0, 5, 5)
			if istable( v ) then
				key:SetText(k .. " : ")
				for k1,v1 in pairs(v) do
					local key2 = self.player.data:Add("DLabel")
					key2:SetColor(color_white)
					key2:SetFont("nutSmallFont")
					key2:Dock(TOP)
					key2:DockMargin(5, 0, 5, 5)
					key2:SetText("___" .. k1 .. " - ".. tostring(v1))
					datalist2[#datalist2 + 1] = key2
				end
			else
				key:SetText(k .. " - ".. tostring(v))
			end
			datalist[#datalist + 1] = key
		end
		
		for k3,v3 in pairs(player.GetAll()) do
			
			
			local label = self.scroll:Add("DButton")
			label:Dock(TOP)
			label:DockMargin(1,0,1,5)
			label:SetTall(32)
			label.player = v3
			
			local textlabel = label:Add("DLabel")
			textlabel:SetColor(color_white)
			textlabel:SetFont("nutSmallFont")
			textlabel:SetText(v3:Name() .. "  |  " .. v3:SteamID())
			textlabel:Dock(FILL)
			
			label:SetText("")
			label.color = Color(255, 255, 255, 0)
			label.DoClick = function(s)
				netstream.Start("gcd", v3)
				curplayer = v3
				self.player.model:SetModel(v3:GetModel())
				self.player.name:SetText("Имя : " .. v3:Name())
				self.player.steam:SetText("SteamID : " ..v3:SteamID() )
				self.player.faction:SetText("Фракция : " ..team.GetName(v3:Team()) )
				self.player.money:SetText("Деньги : " ..v3:getChar():getMoney() )
				for n,key in pairs(datalist) do
					key:Remove()
				end
				
				for n,key in pairs(datalist2) do
					key:Remove()
				end
				
				for k,v in pairs(CharData) do
					local key = self.player.data:Add("DLabel")
					key:SetColor(color_white)
					key:SetFont("nutSmallFont")
					key:Dock(TOP)
					key:DockMargin(5, 0, 5, 5)
					if istable( v ) then
						key:SetText(k .. " : ")
						for k1,v1 in pairs(v) do
							local key2 = self.player.data:Add("DLabel")
							key2:SetColor(color_white)
							key2:SetFont("nutSmallFont")
							key2:Dock(TOP)
							key2:DockMargin(5, 0, 5, 5)
							key2:SetText("___" .. k1 .. " - ".. tostring(v1))
							datalist2[#datalist2 + 1] = key2
						end
					else
						key:SetText(k .. " - ".. tostring(v))
					end
					datalist[#datalist + 1] = key
				end
			end
			label.Paint = function(s, w, h) 
				surface.SetDrawColor(65, 65, 65, 150)
				surface.DrawRect(0, 0, w, h)
			end
		end
		
		self.player.buttonlist = self.player:Add("DScrollPanel")
		self.player.buttonlist:Dock(FILL)
		self.player.buttonlist:DockMargin(ScrW*0.25, 5, 5, ScrH*0.5)
		self.player.buttonlist.VBar:SetWide(5)
		self.player.buttonlist.Paint = function(s, w, h) 
			surface.SetDrawColor(0, 0, 0, 150)
			surface.DrawRect(0, 0, w, h)
		end
		
		local sbar = self.player.buttonlist:GetVBar()
		function sbar:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))
		end
		function sbar.btnUp:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(200, 100, 0))
		end
		function sbar.btnDown:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(200, 100, 0))
		end
		function sbar.btnGrip:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(65, 65, 65))
		end
		
		for k,v in pairs(PLUGIN.commands) do
			local label = self.player.buttonlist:Add("DButton")
			label:Dock(TOP)
			label:DockMargin(1,0,1,5)
			label:SetTall(16)
			label.player = v3
			
			local textlabel = label:Add("DLabel")
			textlabel:SetColor(color_white)
			textlabel:SetFont("nutSmallFont")
			textlabel:SetText("Команда: ".. k .." - "..v.desc)
			textlabel:Dock(FILL)
			
			label:SetText("")
			label.color = Color(65, 65, 65, 150)
			label.DoClick = function(self)
				if v.needarg then 
					Derma_StringRequest( 
					k, 
					"Введите аргументы выделяя в \" - " .. v.argamount, 
					"", 
					function(text) nut.command.send(k, curplayer:Name(), text) end,
					function(text) end,
					"OK",
					"Отмена")
				else
					nut.command.send(k, curplayer:Name())
				end
			end
			label.Paint = function(s, w, h) 
				surface.SetDrawColor(s.color)
				surface.DrawRect(0, 0, w, h)
			end
			label.Think = function(s)
				if (s:IsHovered()) then
					s.color = Color(85, 85, 85, 150)
				else
					s.color = Color(65, 65, 65, 150)
				end
			end
		end
		
		self.player.buttonlist2 = self.player:Add("DScrollPanel")
		self.player.buttonlist2:Dock(FILL)
		self.player.buttonlist2:DockMargin(ScrW*0.25, ScrH*0.3, 5, 5)
		self.player.buttonlist2.VBar:SetWide(5)
		self.player.buttonlist2.Paint = function(s, w, h) 
			surface.SetDrawColor(0, 0, 0, 150)
			surface.DrawRect(0, 0, w, h)
		end
		
		local sbar2 = self.player.buttonlist2:GetVBar()
		function sbar2:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))
		end
		function sbar2.btnUp:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(200, 100, 0))
		end
		function sbar2.btnDown:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(200, 100, 0))
		end
		function sbar2.btnGrip:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(65, 65, 65))
		end
		
		for k,v in pairs(serverguard.command.stored) do
			if k == "menu" then continue end
			local label = self.player.buttonlist2:Add("DButton")
			label:Dock(TOP)
			label:DockMargin(1,0,1,5)
			label:SetTall(16)
			label.player = v3
			
			local textlabel = label:Add("DLabel")
			textlabel:SetColor(color_white)
			textlabel:SetFont("nutSmallFont")
			textlabel:SetText("Команда: ".. k .." - "..v.help)
			textlabel:Dock(FILL)
			
			label:SetText("")
			label.color = Color(65, 65, 65, 150)
			label.DoClick = function(self)
				Derma_StringRequest( 
					k, 
					"Введите аргументы выделяя в \" ",
					"", 
					function(text) serverguard.command.Run(k, true, text) end,
					function(text) end,
					"OK",
					"Отмена")
				
			end
			label.Paint = function(s, w, h) 
				surface.SetDrawColor(s.color)
				surface.DrawRect(0, 0, w, h)
			end
			label.Think = function(s)
				if (s:IsHovered()) then
					s.color = Color(85, 85, 85, 150)
				else
					s.color = Color(65, 65, 65, 150)
				end
			end
		end
	end
	
	function PANEL:Paint(w, h)
	
		nut.util.drawBlur(self, 10)
		surface.SetDrawColor(0, 0, 0, 220)
		surface.DrawRect(2, 2, w - 4, h - 4)

		surface.SetDrawColor(30, 30, 30, 100)
		surface.DrawRect(0, 0, w, h)

		surface.SetDrawColor(175, 175, 175, 200)
		surface.DrawOutlinedRect(0, 0, w, h, 3)
	end
	
vgui.Register("admingui", PANEL, "DFrame")

net.Receive("openadminmenu", function()
    vgui.Create("admingui")
end)

netstream.Hook("recieveData", function(data)
	CharData = data
end)