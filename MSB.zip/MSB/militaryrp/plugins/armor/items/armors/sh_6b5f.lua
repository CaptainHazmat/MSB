﻿ITEM.name = "6Б5-15 - Улей (Флора)"
ITEM.desc = "Бронежилет 6Б5 был принят на снабжение вооруженных сил СССР в 1986 году и представлял собой первую попытку создания унифицированного жилета. \n\nХАРАКТЕРИСТИКИ: \n-усиленная бронезащита \n-4 класс защиты"
ITEM.price = 49263
ITEM.ric = 25
ITEM.dmgsteal = 45
ITEM.exRender = false
ITEM.addition = 2
ITEM.weight = 12.20

ITEM.model = "models/tushingame/tg_armor/tg_6b5_flora.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(4, 2.5, 200),
	ang = Angle(90, 0, 180),
	fov = 8
}

local DuseArmor = {
	"kevlar",
	"armbr",
	"trapk",
	"kevlar",
	"dlarmor"
}